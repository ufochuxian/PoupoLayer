package com.github.codesniper.poplayer.strategy;

import android.view.View;

public interface BasicStrategy {

    View getViewById(int id);
}
