package com.github.codesniper.poplayer.custom.newPop;

public interface IWindowEvent {

    public void onWindowShow();

    public void onWindowDismiss();

}
