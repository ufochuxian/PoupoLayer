package com.github.codesniper.poplayer.impl;


import com.github.codesniper.poplayer.interfaces.PushManager;

/**
 * 在单独的功能模块 执行命令时装配环境
 * 推送功能模块
 * @author  ch
 * Created by mac on 2018/7/10.
 */

public class PushManagerImpl implements PushManager {

    @Override
    public void onReceivePushEvent() {

    }
}
