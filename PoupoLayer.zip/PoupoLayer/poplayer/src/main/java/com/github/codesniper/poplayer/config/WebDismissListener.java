package com.github.codesniper.poplayer.config;

/**
 *  webview消失的回调 类似dialog内置的消失回调
 */

public interface WebDismissListener {
    void onPopDimiss();
}
