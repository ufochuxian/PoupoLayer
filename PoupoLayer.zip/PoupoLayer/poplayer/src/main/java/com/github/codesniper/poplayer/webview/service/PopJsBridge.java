package com.github.codesniper.poplayer.webview.service;

/**
 * @Author：陈鸿 on 2019\2\3 0003 19:46
 * 邮箱：15168264355@163.com
 */
public class PopJsBridge {

    //jsbridge功能封装









}
