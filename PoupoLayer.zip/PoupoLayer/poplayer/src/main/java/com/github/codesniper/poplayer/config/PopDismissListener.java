package com.github.codesniper.poplayer.config;

/**
 * Poplayer通用回调
 */

public interface PopDismissListener  {
    void onPopDimiss();
}
