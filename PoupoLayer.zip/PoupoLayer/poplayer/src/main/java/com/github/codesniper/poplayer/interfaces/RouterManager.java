package com.github.codesniper.poplayer.interfaces;
//Thanks For Your Reviewing My Code 
//Please send your issues email to 15168264355@163.com when you find there are some bugs in My class 
//You Can add My wx 17620752830 and we can communicate each other about IT industry
//Code Programming By MrCodeSniper on 2018/7/4.Best Wishes to You!  []~(~▽~)~* Cheers!

/**
 * 导航管理 弹窗路由跳转
 */
public interface RouterManager {
  //一般用各自项目的路由处理 本模块不做实现
  void routeTo(String routePath);
}
